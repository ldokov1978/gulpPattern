const { src, dest, watch } = require('gulp');
const less = require('gulp-less');
const lessAutoprefix = require('less-plugin-autoprefix');
const autoprefix = new lessAutoprefix({ browsers: ['last 10 versions'] });
const cssmin = require('gulp-cssmin');
const concat = require('gulp-concat');

function styles() {
  return src('app/less/style.less')
    .pipe(less({
      plugins: [autoprefix]
    }))
    .pipe(cssmin())
    .pipe(concat('style.min.css'))
    .pipe(dest('app/css'))
}

function watching() {
  watch(['app/less/**/*.less'], styles)
}

exports.styles = styles;
exports.watching = watching;